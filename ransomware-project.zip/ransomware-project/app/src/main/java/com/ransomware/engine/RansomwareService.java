package com.ransomware.engine;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.widget.Toast;

public class RansomwareService extends Service {
    @Override
    public void onCreate() {
        super.onCreate();
        Toast.makeText(this, "Ransomware Service Started", Toast.LENGTH_LONG).show();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}